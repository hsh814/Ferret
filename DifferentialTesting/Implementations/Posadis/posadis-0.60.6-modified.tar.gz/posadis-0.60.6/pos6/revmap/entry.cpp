/***************************************************************************
                          entry.cpp  -  library entry point function
                             -------------------
    begin                : do jan 2 2003
    copyright            : (C) 2003 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <zones.h>
#include <lib.h>
#include "formap.h"
#include "revmap.h"

Zone *create_formap_zone() {
  return new FormapZone();
}

Zone *create_revmap_zone() {
  return new RevmapZone();
}

zone_entry revmap_entries[] = {
  { "formap", create_formap_zone },
  { "revmap", create_revmap_zone },
  { "", NULL }
};

extern "C" zone_entry* /*revmap_LTX_*/get_zones() { return revmap_entries; }
