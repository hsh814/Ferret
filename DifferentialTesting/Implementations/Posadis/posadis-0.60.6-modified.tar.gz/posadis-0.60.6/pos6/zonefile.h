/***************************************************************************
                          zonefile.h  -  support for zone files
                             -------------------
    begin                : su oct 5 2003
    copyright            : (C) 2003 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 
#ifndef __POSADIS_ZONEFILE_H
#define __POSADIS_ZONEFILE_H

#include <poslib/poslib.h>

void load_zone_file(domainname &znroot, const char *fname, bool finalize);
bool is_zonefile(const char *name, domainname &dom);
bool is_masterfile(const char *name, domainname &dom);

#endif /* __POSADIS_ZONEFILE_H */
