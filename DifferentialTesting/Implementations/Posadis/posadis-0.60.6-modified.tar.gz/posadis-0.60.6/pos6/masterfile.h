/***************************************************************************
                          masterfile.h  -  master file i/o
                             -------------------
    begin                : Wed Dec 25 2002
    copyright            : (C) 2002 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __POSADIS_MASTERFILE_H
#define __POSADIS_MASTERFILE_H

#include "primary.h"
#include <stdio.h>

char *build_filename(domainname &dom, uint32_t serial);
void load_master_file(PrimaryZone *zn, domainname zon, const char *file);
void load_initial_cache(const char *file);

#endif /* __POSADIS_MASTERFILE_H */
