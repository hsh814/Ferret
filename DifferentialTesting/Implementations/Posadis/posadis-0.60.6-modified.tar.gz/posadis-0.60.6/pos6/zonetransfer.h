/***************************************************************************
                          zonetransfer.h  -  handle zone transfers
                             -------------------
    begin                : za apr 19 2003
    copyright            : (C) 2003 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __POSADIS_ZONETRANSFER_H
#define __POSADIS_ZONETRANSFER_H

#include <poslib/poslib.h>
#include <poslib/server/server.h>

DnsMessage *answer_axfr(pending_query *q);

#endif /* __POSADIS_ZONETRANSFER_H */

