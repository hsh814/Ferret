/***************************************************************************
                          posadisrc.h  -  routines for reading the posadisrc
                             -------------------
    begin                : do sep 4 2003
    copyright            : (C) 2003 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __POSADIS_POSADISRC_H
#define __POSADIS_POSADISRC_H
 
#include <poslib/poslib.h>
#include "zones.h"

typedef void(*setting_fn)(void *userdata1, void *userdata2, const char *argument);
void set_setting(setting_fn fn, void *u1, void *u2, const char *ptr);
void zone_set(Zone *z, char *setting, const char *value);

void read_posadisrc(const char *fname);
void posadisrc_finalize();

#endif /* __POSADIS_POSADISRC_H */
