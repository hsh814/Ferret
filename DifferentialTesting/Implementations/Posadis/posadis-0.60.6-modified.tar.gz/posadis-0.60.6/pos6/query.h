/***************************************************************************
                          query.h  -  query handling
                             -------------------
    begin                : wo dec 25 2002
    copyright            : (C) 2002 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __POSADIS_QUERY_H
#define __POSADIS_QUERY_H

#include <poslib/poslib.h>
#include <poslib/server/server.h>

DnsMessage *new_srvfail(DnsMessage *q, uint16_t rcode);
DnsMessage *srvfail(DnsMessage *q, DnsMessage *a, uint16_t rcode);
DnsMessage *query_entry_point(pending_query *q);

#endif /* __POSADIS_QUERY_H */
