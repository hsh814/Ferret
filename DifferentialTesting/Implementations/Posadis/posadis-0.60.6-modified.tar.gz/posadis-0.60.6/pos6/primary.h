/***************************************************************************
                          primary.h  -  primary zones
                             -------------------
    begin                : Tue Dec 24 2002
    copyright            : (C) 2002 by Meilof
    email                : meilof@users.sourceforge.net
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifndef __POSADIS_PRIMARY_H
#define __POSADIS_PRIMARY_H

#include <poslib/poslib.h>
#include "zones.h"
#include "configuration.h"
#include "auth_mem.h"

class PrimaryZone : public AuthMemZone {
 public:
  PrimaryZone();
  ~PrimaryZone();
  virtual void feed_setting(const char *name, const char *val);
  virtual void end_setting();
//  stl_string filename;
//  uint32_t update_ttl;
  int checksum;
};


#endif /* __POSADIS_PRIMARY_H */
