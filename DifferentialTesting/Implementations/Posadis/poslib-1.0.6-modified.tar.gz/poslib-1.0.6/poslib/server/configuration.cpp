/*
    Posadis - A DNS Server
    The Posadis configuration settings
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "configuration.h"

void poslib_config_init() {
  max_threads = 50;
  conf_request_id_expiration = 60000;
  conf_tcp_in_keepalive = 30000;
  conf_tcp_io_timeout = 10000;
  conf_thread_timeout = 10000;
  conf_waitthreadstime = 10000;
}

class __static_poslib_init {
 public:
  __static_poslib_init() {
    poslib_config_init();
  }
} ___static_poslib_init;

int max_threads;

int conf_request_id_expiration;
int conf_get_request_id_expiration() { return conf_request_id_expiration; }

int conf_tcp_in_keepalive;
int conf_get_tcp_in_keepalive() { return conf_tcp_in_keepalive; }

int conf_tcp_io_timeout;
int conf_get_tcp_io_timeout() { return conf_tcp_io_timeout; }

int conf_thread_timeout;
int conf_get_thread_timeout() { return conf_thread_timeout; }

int conf_waitthreadstime;
int conf_get_waitthreadstime() { return conf_waitthreadstime; }
