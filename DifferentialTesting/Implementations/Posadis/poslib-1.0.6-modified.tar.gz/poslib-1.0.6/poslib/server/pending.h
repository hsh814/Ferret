/*
    Posadis - A DNS Server
    Handle pending incoming answes
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_PENDING_H
#define __POSLIB_SERVER_PENDING_H

#include <poslib/dnsmessage.h>
#include <poslib/socket.h>

/*! \file poslib/server/pending.h
 * \brief pending answer structure
 *
 * This file defines the PendingAnswerUDP structure.
 */

/*!
 * \brief pending answer
 *
 * This class represents a pending incoming answer to a query sent using
 * pos_cliresolver. Applications will not want to use this structure
 * theirselves.
 */
class PendingAnswerUDP {
 public:
  PendingAnswerUDP(int _sockid, DnsMessage* _message, _addr a);
  ~PendingAnswerUDP();
  int sockid;
  DnsMessage *message;
  _addr addr;
};

#endif /* __POSLIB_SERVER_PENDING_H */
