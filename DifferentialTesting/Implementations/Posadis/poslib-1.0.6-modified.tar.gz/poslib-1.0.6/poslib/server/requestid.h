/*
    Posadis - A DNS Server
    Maintenance of IDs for outgoing DNS queries
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_REQUESTID_H
#define __POSLIB_SERVER_REQUESTID_H

#include <pthread.h>

#include <poslib/sysstl.h>
#include <poslib/types.h>
#include <poslib/postime.h>

/*! \file poslib/server/requestid.h
 * \brief request id maintenance
 *
 * This file contains some functions for dealing with request IDs. These
 * functions are only designed and useful for internal purposes; you wouldn't
 * want to use them in your poslib application.
 */

//! Internal mutex. Lock order: m_request_id -> m_expired_requests.
extern pthread_mutex_t m_request_id;
//! Internal mutex. Lock order: m_request_id -> m_expired_requests.
extern pthread_mutex_t m_expired_requests;

class RequestExpirationInfo {
  public:
    RequestExpirationInfo(u_int16 _r_id, postime_t _closetime);

    u_int16 r_id; // the request id
    postime_t closetime; // the time we closed the id
};

//! list of expired requests [m_expired_requests]
extern stl_slist(RequestExpirationInfo) expired_requests;


//! gets a new request id. returns the ID or throws an exception
u_int16 get_request_id();

//! registers the given request id for use
void register_request_id(u_int16 r_id);

//! registers a new request id for use
u_int16 register_new_request_id();

//! releases the given request id for enqueuing in the expired_request_id list
void release_request_id(u_int16 r_id);

//! directly releases a request id
void direct_release_request_id(u_int16 r_id);

//! returns true if the given request id is free
bool check_request_id(u_int16 r_id);

//! this function cleans up expired request ids periodically
void request_id_checkexpired();

#endif /* __POSLIB_SERVER_REQUESTID_H */

