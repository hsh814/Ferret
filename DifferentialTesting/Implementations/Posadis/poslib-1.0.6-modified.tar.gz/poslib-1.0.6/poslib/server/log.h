/*
    Posadis - A DNS Server
    Logging functions
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_LOG_H
#define __POSLIB_LOG_H

#include <poslib-config.h>

#include <poslib/postime.h>
#include <poslib/vsnprintf.h>

#include <stdio.h>
#include <stdarg.h>
#include <time.h>

/*! \file poslib/server/log.h
 * \brief Poslib server logging mechanism
 *
 * This file provices access to the Poslib logging mechanism. Poslib server
 * functions use these logging functions internally. You can use the logging
 * system as well, or you can provide your own logging function pointer so
 * that that function will be called by the Poslib functions.
 *
 * If you want to use the default Poslib logging mechanism, you need to
 * #define POS_DEFAULTLOG before #include-ing poslib/server/server.h in
 * exactly one source file (then, the code for the logging function is loaded).
 * By default though, this logging system will do nothing. For each target
 * you want to enable, #define one or more of the following:
 *  - \b POS_DEFAULTLOG_FILE - Log to file. Also, set the #outfile variable,
 *    a variable of the FILE * type, to the file you want to log to. This is
 *    file is automatically closed down when the server shuts down. The current
 *    time is also logged. You can define POS_DEFAULTLOG_FILE_NOFLUSH to
 *    prevent the log file from being flushed after a log message.
 *  - \b POS_DEFAULTLOG_STDERR - Log to stderr (screen output). Also logs
 *    current time.
 *  - \b POS_DEFAULTLOG_SYSLOG - Log to syslog (Unix only).
 *  - \b POS_DEFAULTLOG_PTR - Call the function identified by the
 *    \p pos_log_fptr function pointer. This function should be of the type:
 *    \code
 *    void logfn(log_context context, log_severity severity, char *message);
 *    \endcode
 *    The message passed through does not contain the time, or the log context
 *    or severity.
 *
 * If you don't want to use the default mechanism, set the #pos_log function
 * pointer to your own custom logging function.
 */

#ifdef HAVE_SYSLOG_H
#include <syslog.h>
#else
#define LOG_INFO 0
#define LOG_WARNING 1
#define LOG_ERR 2
#define LOG_CRIT 3
#endif

/*!
 * \brief logging contexts
 *
 * For each log message, a loging context is passed through to indicate where
 * the error happened.
 */
enum log_context {
  context_none = 0,     /**< nothing particular */
  context_threads = 1,  /**< threads system */
  context_socket = 2,   /**< socket error */
  context_server = 3,   /**< server error */
  context_query =  4,   /**< query error */
  context_conf = 5,     /**< configuration */
  context_zonedata = 6, /**< zone data */
  context_system = 7,   /**< system error */
};

/*!
 * \brief logging severity
 *
 * This indicates the severity of the log message.
 */
enum log_severity {
  log_info = LOG_INFO,       /**< informational */
  log_warning = LOG_WARNING, /**< warning */
  log_error = LOG_ERR,       /**< error */
  log_panic = LOG_CRIT,      /**< critical error */
};


#if defined(_WIN32) && !defined(BUILD_POSD_DLL)
extern __declspec(dllimport) const char log_contexts[][16];
#else
/*! Array containing string descriptions for the various logging context. Can
    be used for custom logging functions. */
extern const char log_contexts[][16];
#endif

#if defined(_WIN32) && !defined(BUILD_POSD_DLL)
extern __declspec(dllimport) void (*pos_log)(log_context context, log_severity severity,
             char *log_fmt, ...);
#else
/*!
 * \brief pointer to logging function
 *
 * This is a pointer to the logging function used by Poslib. The function it
 * points to by default does nothing. Use the \p POS_DEFAULTLOG #define (more
 * info in the log.h file documentation) to use the standard logging
 * functionality.
 */
extern void (*pos_log)(log_context context, log_severity severity,
             char *log_fmt, ...);
#endif

#ifdef POS_DEFAULTLOG

#ifdef POS_DEFAULTLOG_FILE
FILE *outfile = NULL;
#endif

void l_pos_log(log_context context, log_severity severity,
             char *log_fmt, ...);

class __static_log_initializer {
 public:
  __static_log_initializer() {
    pos_log = l_pos_log;
#if defined(POS_DEFAULTLOG_SYSLOG) && defined(HAVE_SYSLOG_H)
    openlog("posadis", LOG_PID, LOG_DAEMON);
#endif
  }
  ~__static_log_initializer() {
#if defined(POS_DEFAULTLOG_SYSLOG) && defined(HAVE_SYSLOG_H)
    closelog();
#endif
#ifdef POS_DEFAULTLOG_FILE
    if (outfile) fclose(outfile);
#endif
  }
} ___static_log_intializer;

#ifdef POS_DEFAULTLOG_FPTR
void(*pos_log_fptr)(log_context context, log_severity severity, char *message) = NULL;
#endif

#ifdef POS_DEFAULTLOG_STDERR
/*!
 * \brief whether to log to stderr
 *
 * If stderr logging is enabled, this will decide whether to do stderr logging.
 * For example, you'll want to set this to false after your server has forked.
 */
bool do_stderr_log = true;
#endif

void l_pos_log(log_context context, log_severity severity,
             char *log_fmt, ...) {
  char buff[4096];
  struct tm *tstruct;
  va_list args;
  time_t tsecs;
  int pos;

  tsecs = time(NULL);
  tstruct = localtime(&tsecs);
  sprintf(buff, "%04d/%02d/%02d %02d:%02d:%02d|", tstruct->tm_year + 1900, tstruct->tm_mon + 1, tstruct->tm_mday, tstruct->tm_hour, tstruct->tm_min, tstruct->tm_sec);
  switch (severity) {
    case log_info:    strcat(buff, "info: "); break;
    case log_warning: strcat(buff, "warning: "); break;
    case log_error:   strcat(buff, "error: "); break;
    case log_panic:   strcat(buff, "panic: "); break;
  }

  if (context != context_none) {
    strcat(buff, "[");
    strcat(buff, log_contexts[context]);
    strcat(buff, "] ");
  }

  pos = strlen(buff);
  va_start(args, log_fmt);
  vsnprintf(&buff[strlen(buff)], sizeof(buff) - strlen(buff) - 1, log_fmt, args);
  va_end(args);

#ifdef POS_DEFAULTLOG_FILE
  if (outfile) fprintf(outfile, "%s\n", buff);
#ifndef POS_DEFAULTLOG_FILE_NOFLUSH
  fflush(outfile);
#endif
#endif
#ifdef POS_DEFAULTLOG_STDERR
  if (do_stderr_log) fprintf(stderr, "%s\n", buff);
#endif
#if defined(POS_DEFAULTLOG_SYSLOG) && defined(HAVE_SYSLOG_H)
  syslog(severity, "%s", strchr(buff, '|') + 1);  
#endif
#ifdef POS_DEFAULTLOG_FPTR
  if (pos_log_fptr) pos_log_fptr(context, severity, buff + pos);
#endif
}

#else /* POS_DEFAULTLOG */
/*!
 * \brief pointer to log file
 *
 * If the default logging functionality is used, this is the pointer to the
 * file Poslib will log to. You need to take care of opening this file yourself
 * (or leave it to NULL if you don't want it (yet)); closing the file when
 * your server closes is done by Poslib.
 *
 * To use this, you'll need to define POS_DEFAULTLOG and POS_DEFAULTLOG_FILE.
 */
extern FILE *outfile;
/*!
 * \brief pointer to additional logging function
 *
 * If the default logging functionality is used, this is a function pointer to
 * a custrom logging function that will be called by pos_log. This implies the
 * function should be thread-safe. Set to NULL by default.
 *
 * To use this, you'll need to define POS_DEFAULTLOG and POS_DEFAULTLOG_FPTR.
 */
extern void(*pos_log_fptr)(log_context context, log_severity severity, char *message);
/*!
 * \brief whether we should log to stdout
 *
 * If set to true (the default), the default logging functionality will log its
 * messages to standard output. You ought to disable this if your server is
 * doing a fork().
 *
 * To use this, you'll need to define POS_DEFAULTLOG and POS_DEFAULTLOG_STDOUT.
 */
extern bool do_stderr_log;
#endif

#endif /* __POSLIB_LOG_H */
