/*
    Posadis - A DNS Server
    Posadis threads
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_POSTHREADS_H
#define __POSLIB_POSTHREADS_H

#include <pthread.h>

/*! \file poslib/server/posthreads.h
 * \brief threading functions
 *
 * This source file contains functions for the Posadis threading system, based
 * on pthreads.
 */

/*! Notifies running threads that they should close down. */
void pos_setquitflag();

/*! Resets the quit flag */
void pos_resetquitflag();

/*! Can be called by threads to check whether they should close down. */
bool pos_quitting();

/*!
 * \brief create thread
 *
 * Creates a new thread using the Poslib threading mechnism.
 * \warning Do \b not use pthread_join on this thread! The poslib threading
 *           mechanism might, when the thread function closes down, assign
 *           the thread to another task. Use a condition instead.
 * \param tr The thread ID is stored here
 * \param start Function the thread should execute
 * \param arg Argument for function
 */
void posthread_create(pthread_t *tr, void *(*start) (void *), void *arg);

/*! Closes down the threading mechanism. */
void posthreads_finish();

extern pthread_cond_t c_pos_shutdown; /**< Broadcast when Posadis shuts down. */

#endif /* __POSLIB_POSTHREADS_H */

