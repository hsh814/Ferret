/*
    Posadis - A DNS Server
    Dns Server Resolver API
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <poslib-config.h>

#include <poslib/socket.h>
#include <poslib/exception.h>
#include <poslib/random.h>

#include <stdio.h>

#include "posthreads.h"
#include "srvresolver.h"
#include "requestid.h"
#include "pending.h"
#include "serverthread.h"

void pos_srvresolver::query(DnsMessage *q, DnsMessage*& a, _addr *server, int flags) {
  stl_slist(_addr) servers;
  servers.push_front(*server);
  query(q, a, servers, flags);
}

void pos_srvresolver::query(DnsMessage *q, DnsMessage*& a, stl_slist(_addr) &servers, int flags) {
  int x = -1; int sockid = 0;
  stl_slist(_addr)::iterator server, sbegin;
  stl_slist(WaitAnswerData) waitdata;
  stl_slist(WaitAnswerData)::iterator it;

  if (servers.empty()) throw PException("Empty servers list for query");

  int z = posrandom() % servers.size();
  sbegin = servers.begin();
  while (z) { z--; sbegin++; }  

  while (++x < n_udp_tries) {
    server = sbegin;
    do {
      try {
        /* register and assign a new query ID */
        q->ID = register_new_request_id();
        sendmessage(q, &*server);
        pthread_mutex_lock(&m_pending_answers);
        waitdata.push_front(WaitAnswerData(q->ID, *server));
        if (waitanswer(a, waitdata, udp_tries[x], it)) {
          release_request_id(q->ID);
          /* answer received */
          if (a->TC && flags == Q_DFL) {
            /* retry using TCP */
            delete a;
            a = NULL;
            sockid = 0;
            try {
              sockid = tcpconnect(&it->from);
              tcpquery(q, a, sockid);
            } catch (PException p) {
              tcpdisconnect(sockid);
              throw PException("Failed to retry using TCP: ", p);
            }
            tcpdisconnect(sockid);
          }
          release_request_id(q->ID);
          return;
        }
        release_request_id(q->ID);
      } catch(PException p) {
        release_request_id(q->ID);
        if (pos_quitting()) break;
        stl_slist(_addr)::iterator s2 = server; s2++;
        if (s2 == servers.end()) throw PException("Resolving failed: ", p);
      }
      server++;
      if (server == servers.end()) server = servers.begin();
    } while (server != sbegin);
  }
  throw PException("No server could be reached!");
}

void pos_srvresolver::sendmessage(DnsMessage *msg, _addr *res, int sockid) {
  if (sockid == -1) sockid = getclientsockid(res);
  if (sockid == -1) throw PException("No suitable client socket found!");
  message_buff buff = msg->compile(UDP_MSG_SIZE);
  udpsend(sockid, buff.msg, buff.len, res);
}

bool pos_srvresolver::waitanswer(DnsMessage*& ans, stl_slist(WaitAnswerData)& wait, int timeout, stl_slist(WaitAnswerData)::iterator& wit, int sockid) {
  /* server implementation */
  timespec end = postimespec(timeout);
  bool found;
  int ret;
  stl_slist(PendingAnswerUDP)::iterator it;

  while (1) {
    /* check whether our data has arrived */
    it = pending_answers.begin();
    while (it != pending_answers.end()) {
      found = false;
      wit = wait.begin();
      while (wit != wait.end()) {
        if (it->message->ID == wit->r_id) {
          found = true;
          if (address_matches(&it->addr, &wit->from)) {
            ans = it->message;
            it->message = NULL;
            pending_answers.erase(it);
            pthread_mutex_unlock(&m_pending_answers);
            return true;
          } else {
            /* wrong server, but still, it's our responsibility */
            it->message = NULL;
            pending_answers.erase(it);
            break;
          }
        }
        wit++;
      }
      if (found) it = pending_answers.begin(); else it++;
    }

    /* apparently, the data isn't quite there yet,
       so do another timed wait */

    ret = pthread_cond_timedwait(&c_data_received, &m_pending_answers, &end);
    if (getcurtime() > end && ret == ETIMEDOUT) {
      /* we've waited long enough now */
      pthread_mutex_unlock(&m_pending_answers);
      return false;
    }
  }
}
