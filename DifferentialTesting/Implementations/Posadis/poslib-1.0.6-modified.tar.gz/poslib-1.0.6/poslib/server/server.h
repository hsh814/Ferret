/*
    Posadis - A DNS Server
    Include file for the Posadis server library
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_SEEVER_H
#define __POSLIB_SERVER_SERVER_H

/*! \file poslib/server/server.h
 * \brief Poslib server include file
 *
 * This is the main include file for the Poslib server library.
 */

/*! \page server Using the server library
 *
 * In order for this to make sense, you should also have read \ref client,
 * since the server is built on top of that. Also, some knowledge of DNS RFC's
 * 1034 and 1035 is highly recommended.
 *
 * In order to be able to use the server library, you'll need to know a little
 * about how it works. The server has one main function, serverthread(), which
 * handles incoming data for the server. This function can be run directly from
 * your program, by running posserver_run(), or in the background, by running
 * posserver_startback(). Stopping the Posadis server can be done by
 * pos_setquitflag().
 *
 * If you want to make the server listen at interfaces, you'll need to add
 * them to the servers list, declared in serverthread.h. You can do this both
 * before starting the Posadis server, or while it is running. If you want to
 * use the latter posibility though, you'll need to obtain a lock on the
 * #m_servers mutex.
 *
 * For example, let's make Posadis listen to the DNS port, 53, on all
 * interfaces:
 * \code
 * try {
 *   _addr a;                                     // the address structure
 *   txt_to_addr(&a, "0.0.0.0", DNS_PORT, false); // listen to all interfaces
 *   // start listning on both udp and tcp
 *   servers.push_front(ServerSocket(ss_udp, udpcreateserver(&a)));
 *   servers.push_front(ServerSocket(ss_tcp, tcpcreateserver(&a)));
 * } catch (PException p) {
 *   printf("Error initializing servers: %s\n", p.message);
 * }
 * \endcode
 *
 * \subsection serverqueries Answering queries
 *
 * Now that the server system is running, we'll want to be able to answer
 * queries. Each query that is being received, is handled by the function the
 * #handle_query function pointer points to. So, by changing that pointer
 * (before the server runs), we can provide our own answers to the queries we
 * receive. For more information on how this works, consult the #handle_query
 * documentation.
 *
 * \subsection serverlogging Logging
 * Poslib has its own logging mechanism you can use. You will need to initialize
 * it in order to be able to report error messages Posadis logs to your users.
 * You can also use this logging function yourself by calling the #pos_log
 * function. See log.h for details.
 *
 * \subsection serverexample Example
 *
 * This is a simple server that will only answer \p A queries for \p acdam.net.
 * and \p www.acdam.net. As such, it isn't really useful except as an example.
 * \include server.cpp
 *
 * And if we compile it like this:
 * \verbatim  g++ `poslib-config --libs --cflags --server` server.cpp -o server \endverbatim
 * And run it like this:
 * \verbatim ./server @3000 \endverbatim
 * We've got ourself a DNS server running at port 3000.
 */
#include "../poslib.h"
#include "configuration.h"
#include "handlequery.h"
#include "log.h"
#include "pending.h"
#include "posthreads.h"
#include "requestid.h"
#include "srvresolver.h"
#include "serverthread.h"
#include "configuration.h"

#endif /* __POSLIB_SERVER_SEEVER_H */
