/*
    Posadis - A DNS Server
    Maintenance of IDs for outgoing DNS queries
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <poslib-config.h>

#include <poslib/bits.h>
#include <poslib/random.h>
#include <poslib/postime.h>
#include <poslib/exception.h>

#include "configuration.h"
#include "requestid.h"
#include <queue>


// this is both a maximum value and a bit mask, so should be 2^n - 1
#define ID_MAX 65535
#define ID_SIZE 8192

char ids[ID_SIZE];
stl_slist(RequestExpirationInfo) expired_requests;
pthread_mutex_t m_request_id;
pthread_mutex_t m_expired_requests;

RequestExpirationInfo::RequestExpirationInfo
  (u_int16 _r_id, postime_t _closetime) {
    r_id = _r_id;
    closetime = _closetime;
}

class _request_id_pool {
 public:
  _request_id_pool() {
    pthread_mutex_init(&m_request_id, NULL);
    pthread_mutex_init(&m_expired_requests, NULL);
    memset(ids, 0, ID_SIZE);
  }
  ~_request_id_pool() {
    pthread_mutex_lock(&m_request_id);
    pthread_mutex_destroy(&m_request_id);
    pthread_mutex_lock(&m_expired_requests);
    pthread_mutex_destroy(&m_expired_requests);
  }
} __request_id_pool;

u_int16 get_request_id() {
  u_int16 id1, id2;
  
  pthread_mutex_lock(&m_request_id);
    
  id1 = posrandom() & ID_MAX;
  id2 = id1;
    
  while (bitisset(ids, id2)) {
    id2++;
//    if (id2 > ID_MAX) id2 = 0;
    if (id2 == id1) throw PException("get_request_id(): No free request IDs left!");
  }
  
  pthread_mutex_unlock(&m_request_id);
  
  return id2;
}

void register_request_id(u_int16 r_id) {
  pthread_mutex_lock(&m_request_id);
  bitset(ids, r_id);
  pthread_mutex_unlock(&m_request_id);
}

u_int16 register_new_request_id() {
  u_int16 r_id;
  
  r_id = get_request_id();
  register_request_id(r_id);
  return r_id;
}

void release_request_id(u_int16 r_id) {
  pthread_mutex_lock(&m_expired_requests);
  expired_requests.push_front(RequestExpirationInfo(r_id, getcurtime()));
  pthread_mutex_unlock(&m_expired_requests);
}

void direct_release_request_id(u_int16 r_id) {
  pthread_mutex_lock(&m_expired_requests);
  bitreset(ids, r_id);
  pthread_mutex_unlock(&m_expired_requests);
}

bool check_request_id(u_int16 r_id) {
  pthread_mutex_lock(&m_request_id);
  bool ret = !bitisset(ids, r_id);
  pthread_mutex_unlock(&m_request_id);
  return ret;
}

void request_id_checkexpired() {
  postime_t now = getcurtime();
  
  pthread_mutex_lock(&m_request_id);
  pthread_mutex_lock(&m_expired_requests);

  stl_slist(RequestExpirationInfo)::iterator it = expired_requests.begin();
    
  while (it != expired_requests.end()) {
    if (it->closetime + conf_request_id_expiration > now) break;
    bitreset(ids, it->r_id);
    it = expired_requests.erase(it);
  }

  pthread_mutex_unlock(&m_expired_requests);
  pthread_mutex_unlock(&m_request_id);
}
