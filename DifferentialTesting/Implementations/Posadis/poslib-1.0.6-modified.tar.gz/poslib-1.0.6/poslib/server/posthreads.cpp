/*
    Posadis - A DNS Server
    Posadis threads
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <pthread.h>
#include <stdio.h>

#include <poslib/sysstl.h>
#include <poslib/postime.h>
#include <poslib/exception.h>
#include <poslib/socket.h>

#include "log.h"
#include "posthreads.h"
#include "configuration.h"

int pos_quit_flag = 0;
bool pos_quitting() { if (pos_quit_flag) return true; else return false; }

class thread_data {
 public:
  thread_data(void*(*_function)(void*), void *_arg) {
    function = _function;
    arg = _arg;
  }

  void *(*function)(void *);
  void *arg;
};


pthread_mutex_t m_threads;
pthread_cond_t c_pos_shutdown;

stl_slist(pthread_t) threads;
pthread_cond_t c_threads;
int n_wait = 0;
stl_slist(thread_data) pending_threads;

class _posthreads_init {
 public:
  _posthreads_init() {
    pthread_mutex_init(&m_threads, NULL);
    pthread_cond_init(&c_threads, NULL);
    pthread_cond_init(&c_pos_shutdown, NULL);
  }
  ~_posthreads_init() {
    pthread_mutex_destroy(&m_threads);
    pthread_cond_destroy(&c_threads);
    pthread_cond_destroy(&c_pos_shutdown);
  }
} __posthreads_intializer;

void remove_thread_from_list(pthread_t tr) {
  stl_slist(pthread_t)::iterator it;
  pthread_mutex_lock(&m_threads);
  it = threads.begin();
  while (it != threads.end()) {
    if (*it == tr) {
      threads.erase(it);
      pthread_mutex_unlock(&m_threads);
      return;
    }
    it++;
  }
  pthread_mutex_unlock(&m_threads);
}

bool thread_is_in_list(pthread_t tr) {
  stl_slist(pthread_t)::iterator it;
  pthread_mutex_lock(&m_threads);
  it = threads.begin();
  while (it != threads.end()) {
    if (*it == tr) {
      pthread_mutex_unlock(&m_threads);
      return true;
    }
    it++;
  }
  pthread_mutex_unlock(&m_threads);
  return false;
}

void *posthread_start(void *orig) {
  thread_data *orig_arg = (thread_data *)orig;
  timespec end;
  stl_slist(thread_data)::iterator it;
  thread_data arg = *orig_arg;
  delete orig_arg;

  pthread_mutex_lock(&m_threads);
  threads.push_front(pthread_self());
  pthread_mutex_unlock(&m_threads);

  try {
    while (1) {
      arg.function(arg.arg);
      if (pos_quitting()) {
        if (thread_is_in_list(pthread_self())) {
          pthread_detach(pthread_self());
          remove_thread_from_list(pthread_self());
        }
        return NULL;
      }
      pthread_mutex_lock(&m_threads);
      n_wait++;
      end = postimespec(conf_thread_timeout);
//        printf("[%d]Thread waiting for new tasks....\n", pthread_self());
      pthread_cond_timedwait(&c_threads, &m_threads, &end);
//        printf("[%d]done waiting, lock obtained\n", pthread_self());
      n_wait--;
      it = pending_threads.begin();
      if (it != pending_threads.end()) {
        /* we have something! */
        arg = *it;
        pending_threads.erase(it);
        pthread_mutex_unlock(&m_threads);
        continue;
      } else {
        /* quit */
//        printf("[%d]Thread closing down....\n", pthread_self());
        pthread_mutex_unlock(&m_threads);
        pthread_detach(pthread_self());
        remove_thread_from_list(pthread_self());
        return NULL;
      }
    }
  } catch (PException p) {
    printf("*** Critical error: thread threw an unhandled exception: %s\n", p.message);
  }
  pthread_detach(pthread_self());
  remove_thread_from_list(pthread_self());
  return NULL;
}

void posthread_create(pthread_t *tr, void *(*start) (void *), void *arg) {
  pthread_mutex_lock(&m_threads);
  if (n_wait == 0) {
    /* no-one is waiting */
    pthread_t tr;
    thread_data *dat = new thread_data(start, arg);
    if (pthread_create(&tr, NULL, posthread_start, dat) != 0) {
      delete dat;
      throw PException("Could not create new thread");
    }
  } else {
    pending_threads.push_front(thread_data(start, arg));
    pthread_cond_signal(&c_threads);
  }
  pthread_mutex_unlock(&m_threads);
}

pthread_cond_t finish_cond;

void *wait_thread(void *arg) {
  stl_slist(pthread_t)::iterator it;
  pthread_t tr;

  while (1) {
    pthread_mutex_lock(&m_threads);
    it = threads.begin();
    if (it != threads.end()) {
      tr = *it;
      threads.pop_front();
      pthread_mutex_unlock(&m_threads);
      pthread_join(tr, NULL);
    } else {
      pthread_mutex_unlock(&m_threads);
      pthread_cond_signal(&finish_cond);
      return NULL;
    }
  }
}

void pos_setquitflag() {
  pos_quit_flag = 1;
  posclient_quitflag = true;
}

void pos_resetquitflag() {
  pos_quit_flag = 0;
  posclient_quitflag = false;
}

void posthreads_finish() {
  pthread_t tr;
  timespec end;

  pos_setquitflag();
  pthread_cond_broadcast(&c_threads);
  pthread_cond_broadcast(&c_pos_shutdown);

  pos_log(context_threads, log_info, "Waiting for threads to finish...");

  pthread_mutex_lock(&m_threads);
  pthread_cond_init(&finish_cond, NULL);

  pthread_create(&tr, NULL, wait_thread, NULL);
  pthread_detach(tr);

  end = postimespec(conf_waitthreadstime);
  pthread_cond_timedwait(&finish_cond, &m_threads, &end);
  if (threads.begin() != threads.end()) {
    /* unwilling threads! */
    pos_log(context_threads, log_error, "Some threads did not respond to close down signal: forcing shutdown!");
  }
  pthread_mutex_unlock(&m_threads);
  pos_log(context_threads, log_info, "All threads closed down");
}
