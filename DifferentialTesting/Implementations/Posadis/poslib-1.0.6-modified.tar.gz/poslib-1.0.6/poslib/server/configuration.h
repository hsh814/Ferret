/*
    Posadis - A DNS Server
    The Posadis configuration settings
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_CONFIGURATION_H
#define __POSLIB_SERVER_CONFIGURATION_H

#include <pthread.h>

/*! \file poslib/server/configuration.h
 * \brief Poslib server configuration
 *
 * This file contains some configurable settings for the Poslib server part.
 * You should set these _before_ the server is running, as (as of Poslib 1.0.2),
 * this data is not protected by a mutex.
 */

/** Sets the configuration settings to their defaults. */
void poslib_config_init();

/*!
 * \brief Maximum number of threads
 *
 * The maximum number of concurrent connection threads the server is willing to
 * handle. After this limit is reached, new TCP connections will be closed
 * directly, and UDP clients will merely receive a SRVFAIL answer. Defaults to
 * 50.
 */
extern int max_threads;

/** The number of milliseconds before a request ID is re-used. Defaults to 60000. */
extern int conf_request_id_expiration;
extern int conf_get_request_id_expiration();

/** The number of milliseconds an incoming TCP connection is kept alive. Defaults to 30000. */
extern int conf_tcp_in_keepalive;
extern int conf_get_tcp_in_keepalive();

/** The number of milliseconds we're willing to wait while reading from TCP. Defaults to 10000. */
extern int conf_tcp_io_timeout;
extern int conf_get_tcp_io_timeout();

/** The number of milliseconds before an inactive thread is closed. Defaults to 10000. */
extern int conf_thread_timeout;
extern int conf_get_thread_timeout();

/** The number of milliseconds before threads that are not responding are closed down. Defaults to 10000. */
extern int conf_waitthreadstime;
extern int conf_get_waitthreadstime();

#endif /* __POSLIB_SERVER_CONFIGURATION_H */
