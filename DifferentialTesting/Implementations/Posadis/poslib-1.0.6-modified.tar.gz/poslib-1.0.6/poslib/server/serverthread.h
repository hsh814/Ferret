/*
    Posadis - A DNS Server
    The main server thread
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_SERVERTHREAD_H
#define __POSLIB_SERVER_SERVERTHREAD_H

#include <pthread.h>

#include <poslib/socket.h>
#include <poslib/sysstl.h>
#include <poslib/postime.h>

#include "pending.h"

/*! \file poslib/server/serverthread.h
 * \brief server thread functions
 *
 * Properties for server sockets.
 */

/*! Socket type */
enum sstype {
  ss_udp,    /**< UDP server socket. */
  ss_tcp,    /**< TCP server socket. */
  ss_client  /**< UDP client socket. */
};

//! Handles data from an UDP server socket.
void udpsock_handledata(int sockid);
//! Handles data from a TCP server socket.
void tcpsock_handledata(int sockid);
//! Handles data from an UDP client socket.
void clientsock_handledata(int sockid);

/*!
 * \brief server socket type
 *
 * This is a server socket structure as found in the #servers list. Add an
 * instance of this to make Posadis handle DNS messages on that socket.
 */
class ServerSocket {
 public:
  /*!
   * \brief constructor
   *
   * Constructor.
   * \param type The socket type
   * \param sockid The socket ID
   */
  ServerSocket(sstype type, int sockid);
  ~ServerSocket();                        /*! Destructor */

  void close();                           /*! Close the socket. */
  void handle_data();                     /*! Called by the server thread. */
  
  sstype type;                            /*! Socket type */
  int sockid;                             /*! Socket ID */
};

/*! Mutex for the #server list. */
extern pthread_mutex_t m_servers;
#if defined(_WIN32) && !defined(BUILD_POSD_DLL)
extern __declspec(dllimport) stl_slist(ServerSocket) servers;
#else
/*! List of sockets the server should listen on. Protected by #m_servers. */
extern stl_slist(ServerSocket) servers;
#endif

/*! Mutex for the #pending_answers list. */
extern pthread_mutex_t m_pending_answers;
/*! List of pending answers. Internal - no need to edit. */
extern stl_slist(PendingAnswerUDP) pending_answers;

/*! Condition for receiving data on a UDP client socket. */
extern pthread_cond_t c_data_received;

extern int udp_client_socket;   /**< UDP client socket. */
extern int udp_client_socket_6; /**< UDP client socket (IPv6); */

int getclientsockid(_addr *a);  /**< Gets UDP client socket appropriate for the given address. */

void *serverthread(void *arg);  /**< The main server thread function. */

/*!
 * \brief check whether to allow TCP connections
 *
 * Every time a TCP connection is opened, this function is run to check whether
 * we are willing to provide TCP connectivity to the given client, given the
 * number of TCP processes already active. If the function returns true, the
 * connection is allowed and a new thread is created to handle it. If, on the
 * other hand, it returns false, the connection is closed down directly. The
 * defalt implementation is to allow a TCP connection if #n_threads is smaller
 * than #max_threads. This function is run with the #m_servers mutex locked.
 * \param a Client trying to connect
 * \param ntcp Current number of TCP connections
 */
extern bool(*allow_tcp_connection)(_addr *a, int ntcp);

/*!
 * \brief Current number of threads
 *
 * The number of currently active threads. Locked by the #m_servers mutex.
 */
extern int n_threads;

/*!
 * \brief cleanup function
 *
 * This is a function to a user function that will be called every once in
 * a while (currently every 5 minutes), that can perform cleanup tasks that
 * take very little time, so that you won't need a separate thread for that.
 * Poslib itself executes a function which cleans up request IDs at this
 * interval, and you can add your own user function to make that be called
 * as well.
 *
 * And I'm going to repeat this: make sure your cleanup function uses very
 * little time because it is executed in the main server thread. This means
 * that while your function is running, new queries will not be answered.
 */
extern void(*user_cleanup_function)(void);

/*!
 * \brief Initialize server resolver system
 *
 * This initializes the server resolver system used by #pos_srvresolver.
 * This might become obsolete in future Poslib releases.
 */
void posserver_init_srvresolver();

/*!
 * \brief Start server in the background
 *
 * Starts the Posadis server thread in the background, returning immediately.
 * \sa posserver_run(), posserver_stop()
 */
void posserver_startback();

/*!
 * \brief Start server in the foreground
 *
 * Starts the Posadis server in the foreground. This function does not return
 * until posserver_stop() is called.
 * \sa posserver_startback(), posserver_stop()
 */
void posserver_run();

/*!
 * \brief Stop the Posadis server
 *
 * Stops the Posadis server. This might take some time because it has to wait
 * until all threads are stopped. This will also close down all sockets Poslib
 * listens to, and clear the servers list.
 * \sa posserver_startback, posserver_run()
 */
void posserver_stop();

#endif /* __POSLIB_SERVER_SERVERTHREAD_H */
