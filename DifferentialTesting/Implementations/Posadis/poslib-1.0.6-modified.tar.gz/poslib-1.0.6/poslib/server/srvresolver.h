/*
    Posadis - A DNS Server
    Dns Resolver API
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_SRVRESOLVER_H
#define __POSLIB_SERVER_SRVRESOLVER_H

#include <poslib/sysstl.h>
#include <poslib/socket.h>
#include <poslib/dnsmessage.h>
#include <poslib/resolver.h>

/*! \file poslib/server/srvresolver.h
 * \brief Posadis server resolver implementation
 *
 * This is the resolver implementation for Posadis server applications. It
 * sends all UDP queries through the same socket, thus saving valuable
 * resources. This does mean though that the Posadis server thread should be
 * running before any pos_srvresolver function is used.
 *
 * The TCP client implementation of pos_srvresolver is the same as that of the
 * client resolver.
 */

/*!
 * \brief Posadis server resolver
 *
 * This is the resolver implementation for Posadis server applications. It
 * sends all UDP queries through the same socket, thus saving valuable
 * resources. This does mean though that the Posadis server thread should be
 * running before any pos_srvresolver function is used.
 *
 * The TCP client implementation of pos_srvresolver is the same as that of the
 * client resolver.
 */
class pos_srvresolver : public pos_resolver {
  public:
  void query(DnsMessage *q, DnsMessage*& a, _addr *server, int flags = Q_DFL);
  void query(DnsMessage *q, DnsMessage*& a, stl_slist(_addr) &servers, int flags = Q_DFL);
  /*!
   * \brief low-level resolver function for sending a message
   *
   * This function sends a DNS message to a specified server using UDP.
   * \param msg The DNS message to send
   * \param res The host to send the message to
   * \param sockid This field has no meaning in the server implementation.
   */
  void sendmessage(DnsMessage *msg, _addr *res, int sockid = -1);
  /*!
   * \brief low-level resolver function for waiting for an answer
   *
   * This function waits for at most the amount of milliseconds specified
   * by timeout until an answer to our query arrives. Since multiple
   * messages for the same query might have been sent out, it asks for a list
   * of sent queries.
   *
   * If no answer is received in time, this function will raise an exception.
   * \param ans If an answer is received, it will be put in this variable
   * \param wait List of sent queries we might get an answer to
   * \param timeout Number of milliseconds to wait at most
   * \param it If an answer is received, this iterator will point to the
   *           message this was an answer to.
   * \param sockid This field has no meaning in the server implementation.
   */
  bool waitanswer(DnsMessage*& ans, stl_slist(WaitAnswerData)& wait, int timeout, stl_slist(WaitAnswerData)::iterator& it, int sockid = -1);
};


#endif /* __POSLIB_SERVER_SRVRESOLVER_H */
