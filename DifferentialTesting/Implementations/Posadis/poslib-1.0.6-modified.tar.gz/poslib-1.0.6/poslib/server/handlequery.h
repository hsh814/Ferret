/*
    Posadis - A DNS Server
    Header for handling data
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __POSLIB_SERVER_HANDLEQUERY_H
#define __POSLIB_SERVER_HANDLEQUERY_H

#include <poslib/dnsmessage.h>
#include <poslib/socket.h>

/*!
 * \file poslib/server/handlequery.h
 * \brief query handling
 *
 * This file contains structures regarding the Posadis query handling
 * architecture.
 */

/*!
 * \brief class containing query information
 *
 * This class contains information about a DNS query.
 */
class pending_query {
 public:
  /*!
   * Default constructor. Sets all fields to zero.
   */
  pending_query();
  /*!
   * Constructor setting all class members. Note that the \p _msg parameter
   * is not copied or destructed by the pending_query class.
   */
  pending_query(int _transport, int _sockid, _addr _qr, DnsMessage *_msg);
  /** Destructor */
  ~pending_query();

  int transport;         /**< T_TCP for a TCP query, or T_UDP for an UDP query. */
  int sockid;            /**< Socket id the query was received from. */
  _addr querier;         /**< Addess of the querier. */
  DnsMessage *message;   /**< DNS query. Not destructed by pending_query. */
};

#if defined(_WIN32) && !defined(BUILD_POSD_DLL)
extern __declspec(dllimport) DnsMessage* (*handle_query)(pending_query *query);
#else
/*!
 * \brief query entry-point function
 *
 * This is the query entry-point function. Servers will set this function
 * pointer to their own function that will handle the queries, prior to
 * starting the server mechanism. This function will be called when a query is
 * received. This can be asynchronously: each query gets its own thread in
 * which it operates. All you have to do is create a DnsMessage with the
 * answer to the query, and return it, or return \p NULL if you don't want to
 * answer the query at all. Poslib will take care of sending the answer back
 * and managing the socket connection.
 *
 * Note that if you don't change this, the default handle_query implementation
 * will be used, which always returns \p NULL .
 * \param query Information about the query (see pending_query).
 * \return Answer to the query, or \p NULL if you don't want to answer.
 */
extern DnsMessage* (*handle_query)(pending_query *query);
#endif

#endif /* __POSLIB_SERVER_HANDLEQUERY_H */
