/*
    Posadis - A DNS Server
    The main server thread
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <poslib-config.h>
#include <poslib/socket.h>

#include <poslib/exception.h>
#include <poslib/dnsdefs.h>

#include "serverthread.h"
#include "posthreads.h"
#include "log.h"
#include "configuration.h"
#include "handlequery.h"
#include "pending.h"
#include "requestid.h"

#include <stdio.h>

pthread_mutex_t m_servers;
stl_slist(ServerSocket) servers;

void(*user_cleanup_function)(void) = NULL;

int udp_client_socket = -1;
#ifdef HAVE_IPV6
int udp_client_socket_6 = -1;
#endif

int getclientsockid(_addr *a) {
  int ressock = -1;
  pthread_mutex_lock(&m_servers);
#ifdef HAVE_IPV6
  if (sock_is_ipv6(a)) ressock = udp_client_socket_6;
#endif
  if (sock_is_ipv4(a)) ressock = udp_client_socket;
  pthread_mutex_unlock(&m_servers);
  return ressock;
}


pthread_mutex_t m_pending_answers;
stl_slist(PendingAnswerUDP) pending_answers;

pthread_cond_t c_data_received;

class __init_servers {
 public:
  __init_servers() {
    pthread_mutex_init(&m_servers, NULL);
    pthread_mutex_init(&m_pending_answers, NULL);
    pthread_cond_init(&c_data_received, NULL);
  }
  ~__init_servers() {
    pthread_mutex_lock(&m_servers);
    pthread_mutex_destroy(&m_servers);
    pthread_mutex_lock(&m_pending_answers);
    pthread_mutex_destroy(&m_pending_answers);
    pthread_cond_destroy(&c_data_received);
  }
} _init_servers;


#define CHECK_INTERVAL 60000

void *serverthread(void *arg) {
  smallset_t set;
  stl_slist(ServerSocket)::iterator s_it;
  int x;

  /* every CHECK_INTERVAL msecs, run a check */
  postime_t next_check = getcurtime() + CHECK_INTERVAL;
  postime_t tmp;

  while (1) {
    if ((tmp = getcurtime()) > next_check) {
      request_id_checkexpired();
      if (user_cleanup_function) user_cleanup_function();
      next_check = tmp + CHECK_INTERVAL;
    }

    /* at first, compile the watchset for all current sockets */
    pthread_mutex_lock(&m_servers);

    set.init(servers.size());

    x = 0;
    s_it = servers.begin();
    while (s_it != servers.end()) {
      set.set(x++, s_it->sockid);
      s_it++;
    }

    pthread_mutex_unlock(&m_servers);

    try {
#ifdef _WIN32
      set.wait(300); /* wait for 300ms */
#else
      set.wait(1000); /* wait for one second */
#endif
    } catch(PException p) { }
    if (pos_quitting()) return NULL;

    /* now check whether there is any data */
    pthread_mutex_lock(&m_servers);

    x = -1;

    s_it = servers.begin();
    while (s_it != servers.end()) {
      if (!set.iserror(++x) && set.isdata(x) && !pos_quitting()) {
        s_it->handle_data();
      }
      s_it++;
    }
    pthread_mutex_unlock(&m_servers);
  }
}

ServerSocket::ServerSocket(sstype _type, int _sockid) {
  sockid = _sockid;
  type = _type;
}

ServerSocket::~ServerSocket() {
}

void ServerSocket::close() {
  try {
    if (type == ss_tcp)
      tcpclose(sockid);
    else
      udpclose(sockid);
  } catch(PException p) { }
}

void ServerSocket::handle_data() {
  if (type == ss_udp) udpsock_handledata(sockid);
  if (type == ss_tcp) tcpsock_handledata(sockid);
  if (type == ss_client) clientsock_handledata(sockid);
}

int n_threads = 0;

/* UDP server sockets */

void *udp_query_thread(void *_q) {
  pending_query *q = (pending_query *)_q;
  DnsMessage *msg = NULL;
  message_buff ret;
  bool query_is_answer = false;
  try {
    if (q->message->QR == true) {
      msg = q->message;
      query_is_answer = true;
    } else {
      msg = handle_query(q);
    }
    if (msg) {
      msg->QR = true;
      msg->ID = q->message->ID;
      ret = msg->compile(UDP_MSG_SIZE);
      udpsend(q->sockid, ret.msg, ret.len, &q->querier);
    }

  } catch (PException e) { }
  if (!query_is_answer && msg) delete msg;
  pthread_mutex_lock(&m_servers);
  n_threads--;
  pthread_mutex_unlock(&m_servers);
  delete q;
  return NULL;
}

void udpsock_handledata(int sockid) {
  _addr a;
  char data[UDP_MSG_SIZE];
  DnsMessage *msg = NULL;
  pending_query *pending = NULL;
  int len = 0, t_ret = 1;
  pthread_t tr;

//  pos_log(context_threads, log_info, "Incoming UDP message");

  try {
    len = udpread(sockid, data, sizeof(data), &a);
    msg = new DnsMessage();
    try {
      msg->read_from_data(data, len);
      if (msg->QR) {
        /* this case needs special handling: if we answer with a QR bit,
           this might cause a flood if the IP number of the 'query' is
           spoofed to another DNS server that doesn't handle this */
        len = 0; /* this way, we won't send an answer */
        throw PException("Question has QR bit set");
      }
    } catch(PException p) {
      /* incorrect query: set meta-message  */
      if (len >= 2) {
        delete msg;        
        msg = new DnsMessage();
        msg->ID = data[0] * 256 + data[1];
        msg->QR = true;
        msg->RCODE = RCODE_QUERYERR;
      } else throw p;
    }
    if (n_threads >= max_threads) {
      if (len >= 2) {
        DnsMessage *ans = new DnsMessage();
        ans->ID = data[0] + data[1];
        ans->RCODE = RCODE_SRVFAIL;
        ans->OPCODE = OPCODE_QUERY;
        if (!msg->questions.empty())
          ans->questions.push_back(*msg->questions.begin());
        message_buff ret = ans->compile(UDP_MSG_SIZE);
        udpsend(sockid, ret.msg, ret.len, &a);
        delete ans; ans = NULL;
      }
    } else {
      pending = new pending_query(T_UDP, sockid, a, msg);
      msg = NULL;
      try {
//        pos_log(context_threads, log_info, "Creating thread...");
        posthread_create(&tr, udp_query_thread, pending);
//        pos_log(context_threads, log_info, "Consider it done");
        n_threads++;
        t_ret = 0;
      } catch (PException p) {
        t_ret = 1;
      }
    }
  } catch(PException p) { }
  if (t_ret && !pending && msg) delete msg;
  if (t_ret && pending) delete pending;
}

/* TCP server sockets */

class tcp_data {
 public:
  int sockid;

  _addr querier;
};

int poslib_n_tcp_connections = 0;

void *tcp_server_thread(void *_data) {
  tcp_data *data = (tcp_data *)_data;
  smallset_t set;
  char len_b[2];
  char *msg = NULL;

  int len = 0;
  pending_query *pend = NULL;
  DnsMessage *answer = NULL;
  message_buff compiled;

  try {
    while (1) {
      if (!tcpisopen(data->sockid)) break;

      /* at first, read the message length */
      tcpreadall(data->sockid, len_b, 2, conf_tcp_io_timeout);
      len = len_b[0] * 256 + len_b[1];
      msg = (char *)malloc(len);
      tcpreadall(data->sockid, msg, len, conf_tcp_io_timeout);
      /* allright, now try and interpret the question */
      pend = new pending_query(T_TCP, data->sockid, data->querier, new DnsMessage());
      answer = NULL;
      try {
        pend->message->read_from_data(msg, len);
        if (pend->message->QR) throw PException("Query has the QR bit set!");
      } catch(PException p) {
        /* the message was incorrect */
        if (len >= 2) {
          answer = new DnsMessage();
          answer->ID = msg[0] * 256 + msg[1];
          answer->RCODE = RCODE_QUERYERR;
        }
      }
      free(msg); msg = NULL;
      /* answer the query */
      if (!answer) answer = handle_query(pend);
      if (answer) {
        char buff[2];
        answer->QR = true;
        answer->ID = pend->message->ID;
        
        compiled = answer->compile(TCP_MSG_SIZE);
        buff[0] = compiled.len / 256;
        buff[1] = compiled.len;
        tcpsendall(data->sockid, buff, 2, conf_tcp_io_timeout);
        tcpsendall(data->sockid, compiled.msg, compiled.len, conf_tcp_io_timeout);
        delete answer; answer = NULL;
      }
      delete pend; pend = NULL;

      /* now, wait for the next query to arrive */
      set.init(1);
      set.set(0, data->sockid);
      set.wait(conf_tcp_in_keepalive);
      if (!set.isdata(0)) break;
    }
  } catch (PException p) { 
  }
  tcpclose(data->sockid);
  delete data;
  if (msg) free(msg);
  if (pend) delete pend;
  if (answer) delete answer;
  pthread_mutex_lock(&m_servers);
  n_threads--;
  poslib_n_tcp_connections--;
  pthread_mutex_unlock(&m_servers);
  return NULL;
}

bool def_allow_tcp_connection(_addr *a, int ntcp) {
  return (n_threads < max_threads);
}

bool(*allow_tcp_connection)(_addr *a, int ntcp) = def_allow_tcp_connection;

void tcpsock_handledata(int sockid) {
  tcp_data *dat = NULL;
  pthread_t tr;
  int x = 1;

  try {
    dat = new tcp_data();
    dat->sockid = tcpaccept(sockid, &dat->querier);
    if (allow_tcp_connection(&dat->querier, poslib_n_tcp_connections)) {
      posthread_create(&tr, tcp_server_thread, dat);
      poslib_n_tcp_connections++;
      n_threads++;
    } else {
      tcpclose(dat->sockid);
      throw PException();
    }
    x = 0;
  } catch (PException P) { }
  if (dat && x != 0) delete dat;
}

/* UDP client sockets */

void *handle_answer(void *_a) {
  PendingAnswerUDP *a = (PendingAnswerUDP *)_a;
  int found = 0;

  pthread_mutex_lock(&m_expired_requests);
  pthread_mutex_lock(&m_pending_answers);

  try {
    if (!check_request_id(a->message->ID)) {
      /* good, the request id is used */
      pthread_mutex_lock(&m_request_id);
      try {
        stl_slist(RequestExpirationInfo)::iterator it = expired_requests.begin();

        while (it != expired_requests.end()) {
          if (a->message->ID == it->r_id) {
            /* in expired list: remove from list as we've got it too late */
            expired_requests.erase(it);
            found = 1;
            break;
          }
          it++;
        }
        if (!found) {
          /* if it wasn't removed, some thread is still waiting, so queue it */
          pending_answers.push_front(*a);
          pthread_cond_broadcast(&c_data_received);
        }
      } catch(PException p) { }
      pthread_mutex_unlock(&m_request_id);
    } else {
      /* this messages comes as a complete surprise for us... */
    }  
  } catch(PException p) {  }

  pthread_mutex_unlock(&m_pending_answers);
  pthread_mutex_unlock(&m_expired_requests);

  delete a;
  return NULL;
}

void clientsock_handledata(int sockid) {
  char buff[UDP_MSG_SIZE];
  int len;
  _addr a;
  DnsMessage *msg = NULL;
  PendingAnswerUDP *pending = NULL;
  int t_ret = 1;
  pthread_t tr;

  try {
    len = udpread(sockid, buff, sizeof(buff), &a);
    msg = new DnsMessage();

    msg->read_from_data(buff, len);
    pending = new PendingAnswerUDP(sockid, msg, a);
    msg = NULL;
    posthread_create(&tr, handle_answer, pending);
    t_ret = 0;
  } catch(PException p) { }

  if (t_ret && pending) { delete pending; }
  if (msg) delete msg;
}

void posserver_init_srvresolver() {
  /* open client sockets */
  _addr a;
  try {
    getaddress(&a, "0.0.0.0", 0);
    udp_client_socket = udpcreateserver(&a);
    servers.push_front(ServerSocket(ss_client, udp_client_socket));
  } catch (PException p) {
    pos_log(context_socket, log_error, "Could not create IPv4 client socket: %s", p.message);
  }

#ifdef HAVE_IPV6
  try {
    getaddress(&a, "::1", 0);
    udp_client_socket_6 = udpcreateserver(&a);
    servers.push_front(ServerSocket(ss_client, udp_client_socket_6));
  } catch(PException p) {
    pos_log(context_socket, log_error, "Could not create IPv6 client socket: %s", p.message);
  }
#endif
}

void posserver_startback() {
  pos_resetquitflag();
  pthread_t tr1;
  posthread_create(&tr1, serverthread, NULL);
}

void posserver_run() {
  pos_resetquitflag();
  serverthread(NULL);
  posserver_stop();
}

void posserver_stop() {
  pos_setquitflag();
  posthreads_finish();
  /* close all server sockets */
  stl_slist(ServerSocket)::iterator it = servers.begin();
  while (it != servers.end()) {
    it->close();
    it++;
  }
  servers.clear();
}
