/*
    Posadis - A DNS Server
    A forwarding-only DNS server using Poslib
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#define POS_DEFAULTLOG
#define POS_DEFAULTLOG_STDERR
#define POS_DEFAULTLOG_SYSLOG

#include <poslib/server/server.h>

#ifndef __BORLANDC__
#include <unistd.h>
#endif
#include <stdlib.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>

DnsMessage *my_handle_query(pending_query *query);

void cleanup(int sig) {
  pos_setquitflag();
}

_addr them;

int main(int argc, char **argv) {
  _addr we;

  try {
    /* get command-line arguments */
    if (argc == 2) {
      txt_to_addr(&we, "0.0.0.0");
      txt_to_addr(&them, argv[1]);
    } else if (argc == 3 && argv[1][0] == '@') {
      /* address given */
      txt_to_addr(&we, argv[1] + 1);
      txt_to_addr(&them, argv[2]);
    } else if (argc != 1) {
      printf("Usage: fileserver [@interface] server\n");
      return 1;
    }

    /* bring up posadis */
    servers.push_front(ServerSocket(ss_udp, udpcreateserver(&we)));
    servers.push_front(ServerSocket(ss_tcp, tcpcreateserver(&we)));

    pos_log(context_none, log_info, "Posadis tunneld starting up...");

    signal(SIGINT, cleanup);
    signal(SIGTERM, cleanup);

    handle_query = my_handle_query;
    posserver_init_srvresolver();
    posserver_run();
  } catch (PException p) {
    printf("Fatal exception: %s\n", p.message);
    return 1;
  }

  return 0;
}

/* the entry function which will handle all queries */

DnsMessage *my_handle_query(pending_query *query) {
  pos_srvresolver res;
  DnsMessage *a = NULL;
  if (query->transport == T_TCP) {
    /* client used tcp, s let's use tcp as well */
    int sockid = -1;
    try {
      sockid = res.tcpconnect(&them);
      res.tcpquery(query->message, a, sockid);
      res.tcpdisconnect(sockid);
      a->ID = query->message->ID;
    } catch(PException p) {
      pos_log(context_server, log_info, "TCP tunneling failed: %s", p.message);
      res.tcpdisconnect(sockid);
      if (a) delete a;
      a = new DnsMessage();
      a->ID = query->message->ID;
      a->RCODE = RCODE_SRVFAIL;
    }
  } else {
    try {
      res.query(query->message, a, &them);
      a->ID = query->message->ID;
    } catch(PException p) {
      pos_log(context_server, log_info, "UDP tunneling failed: %s", p.message);
      if (a) delete a;
      a = new DnsMessage();
      a->ID = query->message->ID;
      a->RCODE = RCODE_SRVFAIL;
    }
  }
  return a;
}
