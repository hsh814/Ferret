/*
    Posadis - A DNS Server
    A DNS file client using the Posadis server library
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <poslib/poslib.h>

int main(int argc, char **argv) {
  DnsMessage *q = NULL, *a = NULL;
  char q3[PATH_MAX], *q2 = "", *query = q3, *ptr, *ptr2;
  _addr server;
  domainname dom = "", label;
  stl_list(DnsRR)::iterator it;

  try {
    if (argc != 2) {
      if (argc != 3 || argv[1][0] != '@') {
        printf("Usage: fileclient [@server] file\n");
        return 1;
      } else {
        txt_to_addr(&server, argv[1] + 1);
        q2 = argv[2];
      }
    } else {
      q2 = argv[1];
      getaddress(&server, "127.0.0.1", DNS_PORT);
    }

    strcpy(q3, q2);

    while (1) {
      ptr = strchr(query, '/');
      if (ptr) *ptr = 0;

      /* replace "." with "/" */
      while ((ptr2 = strchr(query, '.'))) *ptr2 = '/';

      label = dom;
      dom = domainname(query);
      dom += label;
      if (ptr) query = ptr + 1; else break;
    }

    /* now execute the query */
    pos_cliresolver res;
    stl_string str;
    bool header = false;

    q = new DnsMessage();
    q->RD = true;
    q->questions.push_front(DnsQuestion(dom, QTYPE_ANY, CLASS_IN));

    res.query(q, a, &server);

    if (a->TC)
      printf("The answer was truncated.\n");

    if (a->RCODE != RCODE_NOERROR)
      printf("  (error: %s)\n", str_rcode(a->RCODE).c_str());

    it = a->answers.begin();
    while (it != a->answers.end()) {
      if (it->TYPE == DNS_TYPE_TXT) {
        if (!header) {
          printf("Directory listing of %s:\n", q2);
          header = true;
        }
        str = rr_tostring(DNS_TYPE_TXT, it->RDATA, it->RDLENGTH);
        printf("  %s\n", str.c_str());
      } else if (it->TYPE == DNS_TYPE_NULL) {
        printf("%s", it->RDATA);
      }
      it++;
    }
    if (q) delete q;
    if (a) delete a;
  } catch (PException p) {
    if (q) delete q;
    if (a) delete a;
    printf("fileclient failed: %s\n", p.message);
    return 1;
  }
  return 0;
}
