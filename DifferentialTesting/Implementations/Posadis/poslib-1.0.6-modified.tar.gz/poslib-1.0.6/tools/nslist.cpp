/*
    Posadis - A DNS Server
    List nameservers for a given domain name
    Copyright (C) 2002  Meilof Veeningen <meilof@users.sourceforge.net>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <poslib/poslib.h>

int main(int argc, char **argv) {
  pos_cliresolver resolver;
  DnsMessage *q = NULL, *a = NULL;
  _addr server;
  char *query;
  stl_list(DnsRR)::iterator it;
  int n_servers = 0;

  try {  
    if (argc != 2) {
      if (argc != 3 || argv[1][0] != '@') {
        printf("Usage: nslist [@server] zone\n");
        return 1;
      } else {
        txt_to_addr(&server, argv[1] + 1);
        query = argv[2];
      }
    } else {
      query = argv[1];
      getaddress(&server, "127.0.0.1", DNS_PORT);
    }

    q = new DnsMessage();
    q->questions.push_front(DnsQuestion(query, DNS_TYPE_NS, CLASS_IN));
    q->RD = true;
    resolver.query(q, a, &server);

    printf("Nameservers for %s:\n", query);

    if (!a->AA)
      printf("  (the answer was not authoritative)\n");

    if (a->RCODE != RCODE_NOERROR)
      printf("  (error: %s)\n", str_rcode(a->RCODE).c_str());

    it = a->answers.begin();

    while (it != a->answers.end()) {
      if (it->TYPE == DNS_TYPE_NS) {
        n_servers++;
        printf(" --> %s\n", dom_tostring(it->RDATA).c_str());
      }
      it++;
    }
    if (n_servers == 0)
      printf("  (no nameservers listed)\n");

    if (q) delete q;
    if (a) delete a;
  } catch(PException p) {
    printf("Lookup failed: %s\n", p.message);
    if (q) delete q;
    if (a) delete a;
    return 1;
  }
  return 0;
}
